const arrAll=[1,2,3,4];

var IndexLayoutStyle, GamePageLayoutStyle;

var currentTile;
var tileStyle;
var clickedTileStyle;