function setPurpleTheme() {
    tileStyle = tileStylePurple;
    clickedTileStyle = clickedTileStylePurple;
    gamePageLayoutStyle = "../../../css/purpleGamePlayLayout.css";
    indexLayoutStyle = "./css/indexPurple.css";
}

function setWhiteTheme() {
    tileStyle = tileStyleWhite;
    clickedTileStyle = clickedTileStyleWhite;
    gamePageLayoutStyle = "../../../css/whiteGamePlayLayout.css";
    indexLayoutStyle = "./css/indexWhite.css";
}

setPurpleTheme();